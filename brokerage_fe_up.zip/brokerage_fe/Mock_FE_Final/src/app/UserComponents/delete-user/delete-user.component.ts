import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-delete-user',
  templateUrl: './delete-user.component.html',
  styleUrls: ['./delete-user.component.css']
})
export class DeleteUserComponent {

  
  userData:any;

  constructor(private route:ActivatedRoute,private router: Router, private service:UserService){}
 
  ngOnInit():void{
  
    var id=this.route.snapshot.paramMap.get("accountId");
    console.log(id);
   
    this.service.deleteUser(id).subscribe(
      (      data: any)=>{
        this.router.navigate(['Login']);
      }
    )
  }
  
}
