import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BrokerageAccount } from '../../models/brokerage-account';
import { User } from '../../models/user';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent {

  userModel: any;

  constructor(private formBuilder:FormBuilder, private router:Router, private userService:UserService, private route:ActivatedRoute){}

  userData:any;
  user:any;
  id:any;
  bid:any;

  
  ngOnInit(): void {
    this.userData = this.route.snapshot.paramMap.get('userData');

    
    this.userModel = JSON.parse(this.userData);
    this.id=this.userModel.userId;
    console.log(this.userModel);

   // this.bid = JSON.parse(this.id);
  // console.log(this.userModel);
}

  userForm = this.formBuilder.group({
 
    UserFirstName:['',[Validators.required,Validators.pattern('[A-Z]{1}[a-zA-z\\s]*'),Validators.minLength(5)]],
    UserLastName:['',Validators.required],
    PrimaryLocation:['',],
    GrossSalary:['',],
    Job:['',],
    JobLocation:['',],
    NickName:['',],
    Password:['',],
    BrokerageAccount:['',]


 
  })

  get controls(){
    return this.userForm.controls; 
  }


  temp:BrokerageAccount[]=[];
  errorMessage:any;

  
  submitForm(data:any){
    
 
    if(data.IsPrimaryUser=="") data.IsPrimaryUser=false;

    let user= new User(0,data.UserFirstName,data.UserLastName,data.PrimaryLocation,data.GrossSalary,data.Job, data.JobLocation,data.NickName,data.Password,this.temp);
    this.userService.editUser(user,this.id).subscribe(
     

      
      {
        next: (data:any)=>{this.userModel=data;alert("user Edited");this.router.navigate(['GetUser']);},
        error: error=>{this.errorMessage=error; console.log(error);}
        }
    )
    console.log(user);
  }

}
