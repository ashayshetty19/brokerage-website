import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BrokerageAccount } from '../../models/brokerage-account';
import { User } from '../../models/user';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent {

  userModel: any;

  constructor(private formBuilder:FormBuilder, private router:Router, private userService:UserService, private route:ActivatedRoute){}

  userData:any;
  user:any;
  id:any;
  bid:any;

  
//   ngOnInit(): void {
//     this.userData = this.route.snapshot.paramMap.get('userData');

    
//     this.userModel = JSON.parse(this.userData);
//     this.id=this.userModel.userId;
//     console.log(this.userModel.userId);

//    // this.bid = JSON.parse(this.id);
//   // console.log(this.userModel);
// }

  userForm = this.formBuilder.group({
 
    UserFirstName:['',[Validators.required,Validators.pattern('[A-Z]{1}[a-zA-Z\\s]*'),Validators.minLength(5),Validators.maxLength(20)]],
    UserLastName:['',[Validators.required,Validators.pattern('[A-Z]{1}[a-zA-Z\\s]*'),Validators.maxLength(20)]],
    PrimaryLocation:['',[Validators.required,Validators.pattern('[A-Z]{1}[a-zA-Z\\s]*'),Validators.maxLength(20)]],
    GrossSalary:['',Validators.required],
    Job:['',[Validators.required,Validators.pattern('[A-Z]{1}[a-zA-Z\\s]*'),Validators.maxLength(20)]],
    JobLocation:['',[Validators.required,Validators.pattern('[A-Z]{1}[a-zA-Z\\s]*'),Validators.maxLength(20)]],
    UserName:['',[Validators.required,Validators.pattern('[A-Z]{1}[a-zA-Z0-9]*'),Validators.minLength(8),Validators.maxLength(15)]],
    Password:['',[Validators.required,Validators.pattern('[A-Z]{1}[a-zA-Z0-9]*'),Validators.minLength(8),Validators.maxLength(15)]],
    BrokerageAccount:['',]


 
  })

  get controls(){
    return this.userForm.controls; 
  }


  temp:BrokerageAccount[]=[];
  errorMessage:any;

  
  submitForm(data:any){
    
 
   console.log(data);
    let user= new User(0,data.UserFirstName,data.UserLastName,data.PrimaryLocation,data.GrossSalary,data.Job, data.JobLocation,data.UserName,data.Password,this.temp);
    this.userService.addUser(user).subscribe(
   

      {
        next: (data:any)=>{this.userModel=data;alert("user Added");this.router.navigate(['Login']);},
        error: error=>{this.errorMessage=error; console.log(error);}
        }
  
    )
    console.log(user);
  }

}
