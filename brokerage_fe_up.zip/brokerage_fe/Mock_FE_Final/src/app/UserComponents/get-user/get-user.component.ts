import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-get-user',
  templateUrl: './get-user.component.html',
  styleUrls: ['./get-user.component.css']
})
export class GetUserComponent {

  user:any;

  constructor(private route:ActivatedRoute,private router: Router, private service:UserService){}
 
  userId:any;
  errorMessage:any;

  ngOnInit():void{
  
    this.userId=sessionStorage.getItem('uid');

    console.log(this.userId);
   
    this.service.getUser(this.userId).subscribe(
     
      
      {
        next: (data:any)=>{ this.user=data;console.log(data);},
        error: error=>{this.errorMessage=error; console.log(error);}
        }
      
    )
  }


  editUser(user:any){
    //this.router.navigate('editUser',user);
    console.log(user);
    this.router.navigate(['EditUser', {userData:JSON.stringify(user)}]);
  }  
  //{userData:JSON.stringify(user)}
  deleteUser(userid:any){
    let result= confirm("u sure?");
    console.log(userid);
    if(result){
    this.router.navigate(['DeleteUser',{accountId:userid}]);
    }
  }




}
