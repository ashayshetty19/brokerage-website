import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddBrokerageComponent } from './BrokerageComponents/add-brokerage/add-brokerage.component';
import { AddBankComponent } from './BankComponents/add-bank/add-bank.component';
import { BankListComponent } from './BankComponents/bank-list/bank-list.component';
import { DeleteBankComponent } from './BankComponents/delete-bank/delete-bank.component';
import { EditBankComponent } from './BankComponents/edit-bank/edit-bank.component';
import { BrokerageListComponent } from './BrokerageComponents/brokerage-list/brokerage-list.component';
import { DeleteBrokerageComponent } from './BrokerageComponents/delete-brokerage/delete-brokerage.component';
import { GetBankComponent } from './BankComponents/get-bank/get-bank.component';

import { GetUserComponent } from './UserComponents/get-user/get-user.component';
import { EditUserComponent } from './UserComponents/edit-user/edit-user.component';
import { DeleteUserComponent } from './UserComponents/delete-user/delete-user.component';
import { AddUserComponent } from './UserComponents/add-user/add-user.component';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
  {path:"", redirectTo:"Login",pathMatch:"full"},
  {path:"BankList", component:BankListComponent},
  {path:"AddBank", component:AddBankComponent},
  {path:"EditBank/:id", component:EditBankComponent},
  {path:"DeleteBank/:id", component:DeleteBankComponent},
  {path:"GetBank", component:GetBankComponent},


  {path:"BrokerageList", component:BrokerageListComponent},
  {path:"DeleteBrokerage", component:DeleteBrokerageComponent},
  {path:"AddBrokerage", component:AddBrokerageComponent},

  {path:"GetUser", component:GetUserComponent},
  {path:"EditUser", component:EditUserComponent},
  {path:"DeleteUser", component:DeleteUserComponent},
  {path:"AddUser", component:AddUserComponent},

  {path:"Login", component:LoginComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }


export const components=[
  BankListComponent, AddBankComponent, EditBankComponent, DeleteBankComponent, GetBankComponent,
  GetUserComponent, EditUserComponent, DeleteUserComponent, AddUserComponent,
  BrokerageListComponent, DeleteBrokerageComponent, AddBrokerageComponent,
  LoginComponent

]
