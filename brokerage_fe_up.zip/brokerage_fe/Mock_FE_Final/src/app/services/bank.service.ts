import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders  } from '@angular/common/http';
import { BankAccount } from '../models/bank-account';
import { Observable } from 'rxjs';
import { catchError, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BankService {

  constructor(private httpClient:HttpClient) { }

  tok:any=sessionStorage.getItem('token');
  

  header = new HttpHeaders().set(
      "Authorization",
      "Bearer " + this.tok
  );
  

  

  getBanks(id:any):Observable<BankAccount[]>{
    console.log(this.header);
    return this.httpClient.get<BankAccount[]>("http://localhost:5269/Bank/GetByBrokerageId/"+id, {headers:this.header})
    .pipe(catchError(this.errorHandler));
  }

  getBank(id:any):Observable<BankAccount>{
    return this.httpClient.get<BankAccount>("http://localhost:5269/Bank/Get/" + id, {headers:this.header})
    .pipe(catchError(this.errorHandler));;
  }

  addBank(bank:any):Observable<BankAccount>{
    return this.httpClient.post<BankAccount>("http://localhost:5269/Bank/Add",bank, {headers:this.header})
    .pipe(catchError(this.errorHandler));;
  }

  editBank(bank:any,id:any):Observable<BankAccount>{
    return this.httpClient.put<BankAccount>("http://localhost:5269/Bank/Update/" + id,bank, {headers:this.header})
    .pipe(catchError(this.errorHandler));;
  }

  deleteBank(id:any):Observable<BankAccount>{
    return this.httpClient.delete<BankAccount>("http://localhost:5269/Bank/Delete/" + id, {headers:this.header})
    .pipe(catchError(this.errorHandler));;
  }

  errorHandler(error:HttpErrorResponse){
    if(error.statusText=='Unknown Error')
      return throwError(() =>new Error("Server Error"));

      var k=String(error.status);
      if(k=="441")
        var s = k + " More than 3 bank accounts cannot be added";
      else if(k=="442")
        var s = k + " More than 2 current bank accounts cannot be added";
      else if(k=="444")
        var s = k + " Owner Name cannot be changed more than twice in a month";
      else if(k="445")
      var s = k + " Bank account cannot be deleted within a month of addition";
      else
        var s=k + " " + error.statusText;
    return throwError(() =>new Error(s));
  }

  

  
}
