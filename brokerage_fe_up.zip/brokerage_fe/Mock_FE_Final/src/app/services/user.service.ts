import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, throwError } from 'rxjs';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpClient:HttpClient) { }

  tok:any=sessionStorage.getItem('token');
  

  header = new HttpHeaders().set(
      "Authorization",
      "Bearer " + this.tok
  );
  

  getUser(id:any):Observable<User>{
    return this.httpClient.get<User>("http://localhost:5269/User/Get/" + id, {headers:this.header})
    .pipe(catchError(this.errorHandler));;
  }

  editUser(user:any,id:any):Observable<User>{
    return this.httpClient.put<User>("http://localhost:5269/User/Update/" + id,user, {headers:this.header})
    .pipe(catchError(this.errorHandler));;
  }

  deleteUser(id:any):Observable<User>{
    return this.httpClient.delete<User>("http://localhost:5269/User/Delete/" + id, {headers:this.header})
    .pipe(catchError(this.errorHandler));;
  }

  addUser(user:any):Observable<User>{
    return this.httpClient.post<User>("http://localhost:5269/User/Add",user, {headers:this.header})
    .pipe(catchError(this.errorHandler));;
  }
  
  errorHandler(error:HttpErrorResponse){
    if(error.statusText=='Unknown Error')
      return throwError(() =>new Error("Server Error"));

      var k=String(error.status);
      
      var s=k + " " + error.statusText;
    return throwError(() =>new Error(s));
  }

}
