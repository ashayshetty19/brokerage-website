import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, throwError } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private httpClient:HttpClient) { }

  
  login(user:any):Observable<String>{
    var s= this.httpClient.post<String>("http://localhost:5269/Auth/logindto", user)
    .pipe(catchError(this.errorHandler));
   
    return s;
  }

  errorHandler(error:HttpErrorResponse){
    if(error.statusText=='Unknown Error')
      return throwError(() =>new Error("Server Error"));

      var k=String(error.status);
      
      var s=k + " " + error.statusText;
    return throwError(() =>new Error(s));
  }


}
