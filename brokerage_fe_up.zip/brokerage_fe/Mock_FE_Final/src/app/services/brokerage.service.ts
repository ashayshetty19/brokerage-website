import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, throwError } from 'rxjs';
import { BrokerageAccount } from '../models/brokerage-account';

@Injectable({
  providedIn: 'root'
})
export class BrokerageService {

  constructor(private httpClient:HttpClient) { }

  tok:any=sessionStorage.getItem('token');
  

  header = new HttpHeaders().set(
      "Authorization",
      "Bearer " + this.tok
  );
  



  getBrokerages(id:any):Observable<BrokerageAccount[]>{
    return this.httpClient.get<BrokerageAccount[]>("http://localhost:5269/Brokerage/GetByUsr/"+id, {headers:this.header})
    .pipe(catchError(this.errorHandler));
  }

  deleteBrokerage(id:any):Observable<BrokerageAccount>{
    return this.httpClient.delete<BrokerageAccount>("http://localhost:5269/Brokerage/Delete/" + id, {headers:this.header})
    .pipe(catchError(this.errorHandler));
  }

  addBrokerage(brokerage:any):Observable<BrokerageAccount>{
    return this.httpClient.post<BrokerageAccount>("http://localhost:5269/Brokerage/Add",brokerage, {headers:this.header})
    .pipe(catchError(this.errorHandler));
  }


  errorHandler(error:HttpErrorResponse){
    console.log(error);
    if(error.statusText=='Unknown Error')
      return throwError(() =>new Error("Server Error"));

      var k=String(error.status);
      
      var s=k + " " + error.statusText;
    return throwError(() =>new Error(s));
  }


  

}
