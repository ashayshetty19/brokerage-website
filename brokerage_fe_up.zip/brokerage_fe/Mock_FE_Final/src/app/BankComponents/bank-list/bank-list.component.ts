import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BankAccount } from '../../models/bank-account';
import { BankService } from '../../services/bank.service';

@Component({
  selector: 'app-bank-list',
  templateUrl: './bank-list.component.html',
  styleUrls: ['./bank-list.component.css']
})
export class BankListComponent implements OnInit{
  constructor(private myService:BankService, private router:Router, private route:ActivatedRoute){}

  banks:any;

  id:any;

  brid:any;

  errorMessage:any;

  ngOnInit(): void {

    this.brid = this.route.snapshot.paramMap.get('id');
    console.log('hi');
    console.log(this.brid);

    this.myService.getBanks(this.brid).subscribe(
      {
        next: (data:any)=>{this.banks = data["$values"];console.log(data["$values"])},
        error: error=>{this.errorMessage=error; console.log(error);}
      })
  
  }

  editBank(bank:any){

   this.router.navigate(['EditBank',this.brid,{bankData:JSON.stringify(bank)}]);
  }  

  deleteBank(bankid:any){
    let result= confirm("Please confirm if you would like to delete this bank detail?");
    console.log(this.brid);

    if(result){
    this.router.navigate(['DeleteBank',this.brid,{accountId:bankid}]);
    }
  }


  infoBank(bankid:any){
 
    this.router.navigate(['GetBank',{accountId:bankid}]);
    
  }

  addBank(){
    this.router.navigate(['AddBank',{accountId:this.brid}]);
  }

}
