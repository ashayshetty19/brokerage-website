import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BankService } from '../../services/bank.service';

@Component({
  selector: 'app-delete-bank',
  templateUrl: './delete-bank.component.html',
  styleUrls: ['./delete-bank.component.css']
})
export class DeleteBankComponent {

  bankData:any;
  errorMessage:any;
  error:any;
  noterror:any;


  brid:any;

  constructor(private route:ActivatedRoute,private router: Router, private service:BankService){}
 
  ngOnInit():void{
  
    var id=this.route.snapshot.paramMap.get("accountId");
   

    this.brid=this.route.snapshot.paramMap.get("id");
    console.log(this.brid);
   
    this.service.deleteBank(id).subscribe(
 
      {
        next: (data:any)=>{this.router.navigate(['BankList',{id:this.brid}]);},
        error: error=>{this.errorMessage=error; console.log(error);}
      }

    )
  }

}
