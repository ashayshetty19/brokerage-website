import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BankAccount } from '../../models/bank-account';
import { BankService } from '../../services/bank.service';

@Component({
  selector: 'app-edit-bank',
  templateUrl: './edit-bank.component.html',
  styleUrls: ['./edit-bank.component.css']
})
export class EditBankComponent {
  bankModel: any;

  constructor(private formBuilder:FormBuilder, private router:Router, private bankService:BankService, private route:ActivatedRoute){}

  bankData:any;
  bank:any;
  id:any;
  bid:any;
  True:boolean=true;

  errorMessage:any;
  error:any;
  noterror:any;


  
  ngOnInit(): void {
    this.bankData = this.route.snapshot.paramMap.get('bankData');
    this.id = this.route.snapshot.paramMap.get('id');

    
   
    this.bankModel = JSON.parse(this.bankData);
   

    console.log(this.id);
    this.bankService.getBank(this.bankModel.accountId).subscribe(
      {
        error: error=>{this.errorMessage=error;}
      }
    )
  // console.log(this.bankModel);
}

  bankForm = this.formBuilder.group({
    OwnerName:['',[Validators.required,Validators.pattern('[A-Z]{1}[a-zA-z\\s]*'),Validators.minLength(5)]],
    AccountNumber:['',Validators.required],
    AccountType:['',Validators.required],
   IsPrimaryBank:['',],
   BrokerageAccount:['',],
   NickName:['',],
   AccountId:['',]


 
  })

  get controls(){
    return this.bankForm.controls; 
  }


  temp:BankAccount[]=[];

  
  submitForm(data:any){
    
 
    if(data.IsPrimaryBank=="") data.IsPrimaryBank=false;

    let bank= new BankAccount(data.OwnerName,data.AccountNumber,data.AccountType,data.NickName,data.IsPrimaryBank,this.bankModel.BrokerageAccount);
    this.bankService.editBank(bank,this.bankModel.accountId).subscribe(

      {
        next: (data:any)=>{this.bankModel=data; alert("bank Edited"); this.router.navigate(['BankList',{id:this.id}])},
        error: error=>{this.errorMessage=error; console.log(error);}
      }


     
    )
    console.log(bank);
  }
}
