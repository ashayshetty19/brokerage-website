import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BankAccount } from '../../models/bank-account';
import { BrokerageAccount } from '../../models/brokerage-account';

import { BankService } from '../../services/bank.service';

@Component({
  selector: 'app-add-bank',
  templateUrl: './add-bank.component.html',
  styleUrls: ['./add-bank.component.css']
})
export class AddBankComponent {

  constructor(private formBuilder:FormBuilder, private router:Router, private bankService:BankService, private route:ActivatedRoute){}


  id:any;

  ngOnInit(): void {

    this.id = this.route.snapshot.paramMap.get('accountId');
    console.log(this.id);

    this.bankService.getBanks(1).subscribe(
      {
        error: error=>{this.errorMessage=error;}
      }
    )
  
  // console.log(this.bankModel);
}

  bankForm = this.formBuilder.group({
    OwnerName:['',[Validators.required,Validators.pattern('[A-Z]{1}[a-zA-z\\s]*'),Validators.minLength(5)]],
    AccountNumber:['',[Validators.required,Validators.pattern('[A-Z]{1}[a-zA-z0-9]*'),Validators.maxLength(16)]],
    AccountType:['',Validators.required],
   IsPrimaryBank:['',],
   
   NickName:['',]


 
  })

  get controls(){
    return this.bankForm.controls; 
  }

  bankModel:any;
  temp:BankAccount[]=[];
  errorMessage:any;
  error:any;
  noterror:any;


  
  submitForm(data:any){
    
 
    if(data.IsPrimaryBank=="") data.IsPrimaryBank=false;

    let bank= new BankAccount(data.OwnerName,data.AccountNumber,data.AccountType,data.NickName,data.IsPrimaryBank,this.id);
    this.bankService.addBank(bank).subscribe(
      {

        next: data=>{ this.bankModel=data;  alert("New Bank Details Added"); this.router.navigate(['BankList',{id:this.id}]);},
        error: error=>{this.errorMessage=error;}
      }

    
    )
    console.log(bank);
  }


}
