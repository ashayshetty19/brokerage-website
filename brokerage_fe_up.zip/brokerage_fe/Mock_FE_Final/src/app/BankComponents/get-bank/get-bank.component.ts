import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BankService } from '../../services/bank.service';

@Component({
  selector: 'app-get-bank',
  templateUrl: './get-bank.component.html',
  styleUrls: ['./get-bank.component.css']
})
export class GetBankComponent {

  bank:any;

  errorMessage:any;

  constructor(private route:ActivatedRoute,private router: Router, private service:BankService){}
 


  ngOnInit():void{
  
    var id=this.route.snapshot.paramMap.get("accountId");
    console.log(id);
   
    this.service.getBank(id).subscribe(
     {
        next: (data:any)=>{this.bank = data;},
        error: error=>{this.errorMessage=error; console.log(error);}
      }
    )
  }

}
