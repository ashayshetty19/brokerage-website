import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule, components } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { BankListComponent } from './BankComponents/bank-list/bank-list.component';
import { HttpClientModule } from '@angular/common/http';
import { AddBankComponent } from './BankComponents/add-bank/add-bank.component';
import { ReactiveFormsModule } from '@angular/forms';

import { EditBankComponent } from './BankComponents/edit-bank/edit-bank.component';
import { DeleteBankComponent } from './BankComponents/delete-bank/delete-bank.component';
import { GetBankComponent } from './BankComponents/get-bank/get-bank.component';

import { GetUserComponent } from './UserComponents/get-user/get-user.component';
import { BrokerageListComponent } from './BrokerageComponents/brokerage-list/brokerage-list.component';
import { DeleteBrokerageComponent } from './BrokerageComponents/delete-brokerage/delete-brokerage.component';
import { AddBrokerageComponent } from './BrokerageComponents/add-brokerage/add-brokerage.component';
import { DeleteUserComponent } from './UserComponents/delete-user/delete-user.component';
import { EditUserComponent } from './UserComponents/edit-user/edit-user.component';
import { AddUserComponent } from './UserComponents/add-user/add-user.component';
import { LoginComponent } from './login/login.component';

import { JwtModule } from "@auth0/angular-jwt";



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    BankListComponent,
    components,
    AddBankComponent,
   
    EditBankComponent,
        DeleteBankComponent,
        GetBankComponent,
        GetUserComponent,
        BrokerageListComponent,
        DeleteBrokerageComponent,
        AddBrokerageComponent,
        DeleteUserComponent,
        EditUserComponent,
        AddUserComponent,
        LoginComponent,
      
  ],
  imports: [
    ReactiveFormsModule,
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    JwtModule.forRoot({
      config: {
        tokenGetter:  () => localStorage.getItem('access_token')
      }
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
