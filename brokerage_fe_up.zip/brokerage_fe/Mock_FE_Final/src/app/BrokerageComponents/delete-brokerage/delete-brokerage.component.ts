import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BrokerageService } from '../../services/brokerage.service';

@Component({
  selector: 'app-delete-brokerage',
  templateUrl: './delete-brokerage.component.html',
  styleUrls: ['./delete-brokerage.component.css']
})
export class DeleteBrokerageComponent {


  constructor(private route:ActivatedRoute,private router: Router, private service:BrokerageService){}

  errorMessage:any;
 
  ngOnInit():void{
  
    var id=this.route.snapshot.paramMap.get("accountId");
    console.log(id);
   
    this.service.deleteBrokerage(id).subscribe(
   
      {
        next: (data:any)=>{ this.router.navigate(['BrokerageList']);},
        error: error=>{this.errorMessage=error; console.log(error);}
      }

      
    )


  }

}
