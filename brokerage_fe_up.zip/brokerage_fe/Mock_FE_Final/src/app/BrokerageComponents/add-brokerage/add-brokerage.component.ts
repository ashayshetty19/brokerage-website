import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BrokerageAccount } from '../../models/brokerage-account';
import { BrokerageService } from '../../services/brokerage.service';

@Component({
  selector: 'app-add-brokerage',
  templateUrl: './add-brokerage.component.html',
  styleUrls: ['./add-brokerage.component.css']
})
export class AddBrokerageComponent {


  constructor(private formBuilder:FormBuilder, private router:Router, private brokerageService:BrokerageService, private route:ActivatedRoute){}

  uid:any;
  ngOnInit(): void {
  
    this.uid = sessionStorage.getItem('uid');
    console.log(this.uid);

    this.brokerageService.getBrokerages(this.uid).subscribe(
      {
     
      error: error=>{this.errorMessage=error; console.log(error);}
      }
    )

 
  // console.log(this.bankModel);
}

  brokerageForm = this.formBuilder.group({

    AccountType:['', Validators.required]
 
  })

  get controls(){
    return this.brokerageForm.controls; 
  }

  brokerageModel:any;
  errorMessage:any;
  temp:BrokerageAccount[]=[];

  
  submitForm(data:any){
    
    


    let brokerage= new BrokerageAccount(0,this.uid,data.AccountType,this.temp);
    this.brokerageService.addBrokerage(brokerage).subscribe(

      {
        next: (data:any)=>{  this.brokerageModel=data; alert("Brokerage Account Added!!!");this.router.navigate(['BrokerageList']);},
        error: error=>{this.errorMessage=error; console.log(error);}
      }
    )
    console.log(brokerage);
  }


}
