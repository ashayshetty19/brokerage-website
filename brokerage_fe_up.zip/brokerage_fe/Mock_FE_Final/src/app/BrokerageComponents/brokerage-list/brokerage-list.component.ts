import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { BrokerageService } from '../../services/brokerage.service';

@Component({
  selector: 'app-brokerage-list',
  templateUrl: './brokerage-list.component.html',
  styleUrls: ['./brokerage-list.component.css']
})
export class BrokerageListComponent {

  constructor(private myService:BrokerageService, private router:Router){}

  brokerages:any;

  userId:any;
  errorMessage:any;
error:any;
noterror:any;


  ngOnInit(): void {


    this.userId=sessionStorage.getItem('uid');


    this.myService.getBrokerages(this.userId).subscribe(
      {
      next: (data:any)=>{this.brokerages = data["$values"];console.log(data["$values"])},
      error: error=>{this.errorMessage=error; console.log(error);}
      }

     
    )
  }


  infoBrokerage(AccountId:any){
    
    this.router.navigate(['BankList',{id:AccountId}]);
    
  }

  deleteBrokerage(AccountId:any){
    console.log(AccountId);
    let result= confirm("Please confirm if you want to delete this Brokerage Account?");
    
    if(result){
    this.router.navigate(['DeleteBrokerage',{accountId:AccountId}]);
    }
  }

  addBrokerage(){
    this.router.navigate(['AddBrokerage']);
  }



}
