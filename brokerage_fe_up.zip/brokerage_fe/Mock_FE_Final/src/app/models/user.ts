export class User {

    constructor(
        public UserId:any,
        public UserFirstName:any,
        public UserLastName:any,
        public PrimaryLocation:any,
        public GrossSalary:any,
        public Job:any,
        public JobLocation:any,
        public UserName:any,
        public Password:any,
        public BrokerageAccount:any

    ){}
}
