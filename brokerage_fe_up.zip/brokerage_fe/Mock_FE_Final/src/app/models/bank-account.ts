import { AnimateTimings } from "@angular/animations";

export class BankAccount {

    constructor(
        
        
        public OwnerName:any,
        public AccountNumber:any,
        public AccountType:any,
        public NickName:any,
        public IsPrimaryBank:any,
      
        public BrokerageAccountId:any
    ){}
    
}
