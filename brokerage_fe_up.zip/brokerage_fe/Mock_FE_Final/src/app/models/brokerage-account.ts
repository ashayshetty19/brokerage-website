export class BrokerageAccount {

    constructor(
        public brokerageAccountId:any,
        public userId:any,
        public accountType:any,
        public bankAccounts:any

    ){}

}

