export class LoginDto {

    constructor(
      
        public UserName:any,
        public Password:any,
    
    ){}
}
