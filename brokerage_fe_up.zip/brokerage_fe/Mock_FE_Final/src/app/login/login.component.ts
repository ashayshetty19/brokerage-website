import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { LoginDto } from '../models/login-dto';
import { LoginService } from '../services/login.service';
import { UserService } from '../services/user.service';
import { JwtHelperService } from '@auth0/angular-jwt';




@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  userModel: any;
  httpClient: any;

  constructor(private formBuilder:FormBuilder, private router:Router, private loginService:LoginService, private route:ActivatedRoute,private jwtHelper: JwtHelperService){}

  userData:any;
  user:any;
  id:any;
  bid:any;
  showPassword = false;
  errorMessage:any;


  
//   ngOnInit(): void {
//     this.userData = this.route.snapshot.paramMap.get('userData');

    
//     this.userModel = JSON.parse(this.userData);
//     this.id=this.userModel.userId;
//     console.log(this.userModel.userId);

//    // this.bid = JSON.parse(this.id);
//   // console.log(this.userModel);
// }

  userForm = this.formBuilder.group({
 

    NickName:['',],
    Password:['',]


 
  })

  get controls(){
    return this.userForm.controls; 
  }




  submitForm(data:any){
    
 
  // console.log(data);
    let userdto= new LoginDto(data.NickName,data.Password);
    this.loginService.login(userdto).subscribe(
     

        {
          next: (data:any)=>{ 
            var apiResponse = data.key;
            const token = this.jwtHelper.decodeToken(apiResponse);
            sessionStorage.setItem('token', apiResponse);
            //console.log(token);
            var uid=token['http://schemas.microsoft.com/ws/2008/06/identity/claims/primarysid'];
            sessionStorage.setItem('uid', uid);
            this.router.navigate(['BrokerageList']);
          },
          error: error=>{this.errorMessage="Invalid UserName or Password!!"; console.log(error);}
          }


      
    )
    
  }


}
