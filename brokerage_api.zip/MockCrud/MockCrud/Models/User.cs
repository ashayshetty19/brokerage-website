﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.RegularExpressions;

namespace MockCrud.Models

{
    public class User
    {
        [Key]
        public int UserId { get; set; }

      

        [Required]
        [StringLength(20)]
        public string? UserFirstName  { get; set; }

        [Required]
        [StringLength(20)]
        public string? UserLastName { get; set; }

        [Required]
        [StringLength(20)]
        public string? PrimaryLocation { get; set; }

        [Required]

        public double? GrossSalary { get; set; }

        [Required]
        [StringLength(20)]
        public string? Job { get; set;}

        [Required]
        [StringLength(20)]
        public string? Joblocation { get; set; }

        [Required]
        [StringLength(15, MinimumLength = 8)]
        [RegularExpression("^[a-zA-Z0-9]*$", ErrorMessage = "Only Alphabets and Numbers allowed.")]
        public string? UserName { get; set; }

        [Required]
        [StringLength(15, MinimumLength = 8)]
        [RegularExpression("^[a-zA-Z0-9]*$", ErrorMessage = "Only Alphabets and Numbers allowed.")]
        [DataType(DataType.Password)]
        public string? Password { get; set; }



     
        public List<BrokerageAccount>? BrokerageAccount { get; set; }
    }
}
