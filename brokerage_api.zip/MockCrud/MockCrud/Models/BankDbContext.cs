﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MockCrud.Models
{
    public class BankDbContext : DbContext
    {
        public BankDbContext(DbContextOptions<BankDbContext> Op) : base(Op)     // recieved connection string
        {

        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
        }

        public DbSet<User> TblUser { get; set; }
        public DbSet<BankAccount> TblBank { get; set; }
        public DbSet<BrokerageAccount> TblBrokerage { get; set; }


    }
}

