﻿namespace MockCrud.Models
{
    public class TokStr
    {
        public string? key { get; set; }

    }
}
