﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MockCrud.Models
{
    public class BankAccount
    {
        [Key]
        public int AccountId { get; set; }
      
        [Required]
        public string? OwnerName { get; set; }

        [Required]
        [StringLength(16)]
        public string? AccountNumber { get; set; }

        [Required]
        public string? AccountType { get; set; }
       
        public string? NickName { get; set; }   

        [Required]
        public bool IsPrimaryBank { get; set; }

        [Required]
        public int Count { get; set; }

        [Required]
        public DateTime OpenedDate { get; set; }

        [Required]
        public DateTime CntDate { get; set; }


        [ForeignKey("BrokerageAccount")]
        public int BrokerageAccountId { get; set; }

        public BrokerageAccount? BrokerageAccount { get; set; }
    }
}
