﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MockCrud.Models
{
    public class BrokerageAccount
    {
        [Key]
        public int BrokerageAccountId { get; set; }


        
        public int UserId { get; set; }
        [ForeignKey("UserId")]
        public User? user { get; set; }

  
        public string? AccountType { get;set; }

        public List<BankAccount>? BankAccounts { get; set; }

    }
}
