﻿using MockCrud.Models;

namespace MockCrud.Token
{
    public interface ITokenHandler
    {
        Task<string> CreateToken(User user);
    }
}
