using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using MockCrud.Models;
using MockCrud.Repository;
using MockCrud.Token;
using System;
using System.Text;
using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers().AddJsonOptions(o => o.JsonSerializerOptions
   .ReferenceHandler = ReferenceHandler.Preserve);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();


builder.Services.AddDbContext<BankDbContext>(options => 
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("ConStr"));
});
builder.Services.AddScoped<ILoginRepository, LoginRepository>();

builder.Services.AddScoped<IUserRepository, UserDbRepository>();
builder.Services.AddScoped<IBankRepository, BankDbRepository>();
builder.Services.AddScoped<IBrokerageRepository, BrokerageDbRepository>();
builder.Services.AddScoped<ITokenHandler, MyTokenHandler>();
builder.Services.AddAutoMapper(typeof(Program).Assembly);

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
               .AddJwtBearer(options => options.TokenValidationParameters = new TokenValidationParameters
               {
                   ValidateIssuer = true,
                   ValidateAudience = true,
                   ValidateLifetime = true,
                   ValidateIssuerSigningKey = true,
                   ValidAudience = builder.Configuration["Jwt:Audience"],
                   ValidIssuer = builder.Configuration["Jwt:Issuer"],
                   IssuerSigningKey = new SymmetricSecurityKey
                   (Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"])),

               });



builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowToReactApp", policy =>
    {

        policy.AllowAnyOrigin();
        policy.AllowAnyMethod();
        policy.AllowAnyHeader();


    });
});


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}


app.UseHttpsRedirection();

app.UseCors("AllowToReactApp");

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.Run();
