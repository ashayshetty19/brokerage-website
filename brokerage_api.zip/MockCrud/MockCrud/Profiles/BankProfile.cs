﻿using AutoMapper;
using MockCrud.DTO;
using MockCrud.Models;

namespace MockCrud.Profiles
{
    public class BankProfile : Profile
    {
        public BankProfile() 
        { 
            CreateMap<BankAccount,BankDTO>().ReverseMap();
        }
    }
}
