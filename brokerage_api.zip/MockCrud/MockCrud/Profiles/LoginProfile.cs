﻿using AutoMapper;
using MockCrud.DTO;
using MockCrud.Models;

namespace MockCrud.Profiles
{
    public class LoginProfile:Profile
    {
        public LoginProfile()
        {

            CreateMap<User, LoginDto>()
                .ForMember(logindto => logindto.UserName, option => option.MapFrom(login => login.UserName))
                .ForMember(logindto => logindto.Password, option => option.MapFrom(login => login.Password));




        }
    }
}
