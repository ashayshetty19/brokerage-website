﻿using MockCrud.Models;
using System.ComponentModel.DataAnnotations;

namespace MockCrud.DTO
{
    public class UserDto
    {
        [Key]
        public int UserId { get; set; }


        public string? UserFirstName { get; set; }

        public string? UserLastName { get; set; }

     
    }
}
