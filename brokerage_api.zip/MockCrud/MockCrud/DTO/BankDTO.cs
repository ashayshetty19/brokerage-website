﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace MockCrud.DTO
{
    public class BankDTO
    {
        public string? OwnerName { get; set; }
        public string? AccountNumber { get; set; }
        public string? AccountType { get; set; }

        public string? NickName { get; set; }
        public bool IsPrimaryBank { get; set; }

        public int BrokerageAccountId { get; set; }

    }
}
