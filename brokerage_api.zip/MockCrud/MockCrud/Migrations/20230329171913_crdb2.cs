﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MockCrud.Migrations
{
    public partial class crdb2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "CntDate",
                table: "TblBank",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<int>(
                name: "Count",
                table: "TblBank",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<DateTime>(
                name: "OpenedDate",
                table: "TblBank",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CntDate",
                table: "TblBank");

            migrationBuilder.DropColumn(
                name: "Count",
                table: "TblBank");

            migrationBuilder.DropColumn(
                name: "OpenedDate",
                table: "TblBank");
        }
    }
}
