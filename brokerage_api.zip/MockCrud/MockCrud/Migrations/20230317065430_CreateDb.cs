﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MockCrud.Migrations
{
    public partial class CreateDb : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "TblUser",
                columns: table => new
                {
                    UserId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserFirstName = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    UserLastName = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    PrimaryLocation = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    GrossSalary = table.Column<double>(type: "float", nullable: false),
                    Job = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    Joblocation = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    UserName = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    Password = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TblUser", x => x.UserId);
                });

            migrationBuilder.CreateTable(
                name: "TblBrokerage",
                columns: table => new
                {
                    BrokerageAccountId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    AccountType = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TblBrokerage", x => x.BrokerageAccountId);
                    table.ForeignKey(
                        name: "FK_TblBrokerage_TblUser_UserId",
                        column: x => x.UserId,
                        principalTable: "TblUser",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TblBank",
                columns: table => new
                {
                    AccountId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OwnerName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AccountNumber = table.Column<string>(type: "nvarchar(16)", maxLength: 16, nullable: false),
                    AccountType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    NickName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsPrimaryBank = table.Column<bool>(type: "bit", nullable: false),
                    BrokerageAccountId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TblBank", x => x.AccountId);
                    table.ForeignKey(
                        name: "FK_TblBank_TblBrokerage_BrokerageAccountId",
                        column: x => x.BrokerageAccountId,
                        principalTable: "TblBrokerage",
                        principalColumn: "BrokerageAccountId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_TblBank_BrokerageAccountId",
                table: "TblBank",
                column: "BrokerageAccountId");

            migrationBuilder.CreateIndex(
                name: "IX_TblBrokerage_UserId",
                table: "TblBrokerage",
                column: "UserId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TblBank");

            migrationBuilder.DropTable(
                name: "TblBrokerage");

            migrationBuilder.DropTable(
                name: "TblUser");
        }
    }
}
