﻿using MockCrud.Models;

namespace MockCrud.Repository
{
    public interface IBankRepository
    {
        Task<List<BankAccount>> GetBanksAsync();

        Task<BankAccount?> GetBankByIdAsync(int id);

        Task<List<BankAccount?>> GetBankByBraIdAsync(int id);


        Task<BankAccount> AddBankAsync(BankAccount Broker);

        Task<BankAccount> EditBankAsync(int id, BankAccount Broker);

        Task<BankAccount> DeleteBankAsync(int id);
    }
}
