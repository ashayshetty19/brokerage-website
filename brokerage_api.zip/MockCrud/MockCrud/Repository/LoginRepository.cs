﻿using Microsoft.EntityFrameworkCore;
using MockCrud.Models;
using System;

namespace MockCrud.Repository
{
    public class LoginRepository: ILoginRepository
    {
        private readonly BankDbContext context;

        public LoginRepository(BankDbContext context)
        {
            this.context = context;
        }

        public async Task<User?> AuthenticateAsync(string username, string password)
        {


            var data = await this.context.TblUser.SingleOrDefaultAsync(u => u.UserName == username && u.Password == password);






            return data;
        }
    }
}
