﻿using MockCrud.Models;

namespace MockCrud.Repository
{
    public interface IUserRepository
    {
        Task<List<User>> GetUsersAsync();

        Task<User?> GetUserByIdAsync(int id);


        Task<User> AddUserAsync(User user);

        Task<User> EditUserAsync(int id, User user);

        Task<User> DeleteUserAsync(int id);
    }
}
