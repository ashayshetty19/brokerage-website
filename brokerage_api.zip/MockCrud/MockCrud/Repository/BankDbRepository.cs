﻿using Microsoft.EntityFrameworkCore;
using MockCrud.Models;

namespace MockCrud.Repository
{
    public class BankDbRepository: IBankRepository
    {
        private BankDbContext _context;


        public BankDbRepository(BankDbContext context)
        { 
            _context = context;

        }

        public async Task<List<BankAccount>> GetBanksAsync()
        {
            var data = await _context.TblBank.Include(r=>r.BrokerageAccount).ToListAsync();
            return data;
        }


        public async Task<BankAccount?> GetBankByIdAsync(int id)
        {
            return await _context.TblBank.Include(r => r.BrokerageAccount).SingleOrDefaultAsync(i => i.AccountId == id);

        }

        public async Task<List<BankAccount?>> GetBankByBraIdAsync(int id)
        {
            var banks = _context.TblBank.Where(i => i.BrokerageAccount.BrokerageAccountId == id).ToList();


            return banks;

        }

        public async Task<BankAccount> AddBankAsync(BankAccount bka)
        {
            var id = bka.BrokerageAccountId;

            var bra= await _context.TblBrokerage.Include(r => r.BankAccounts).SingleOrDefaultAsync(i => i.BrokerageAccountId == id);


            bka.BrokerageAccount=bra;



            bka.OpenedDate = DateTime.Today;
            bka.CntDate = DateTime.Today;




            await _context.AddAsync(bka);

            await _context.SaveChangesAsync();

            return bka;

        }
         
        public async Task<BankAccount> EditBankAsync(int id, BankAccount UpdatedBank)
        {
            var u = await _context.TblBank.FindAsync(id);

            u.OwnerName = UpdatedBank.OwnerName;
            u.AccountNumber= UpdatedBank.AccountNumber;
            u.NickName = UpdatedBank.NickName;
            u.IsPrimaryBank = UpdatedBank.IsPrimaryBank;
            u.AccountType= UpdatedBank.AccountType;

          

            await _context.SaveChangesAsync();
            return u;

        }

        public async Task<BankAccount> DeleteBankAsync(int id)
        {
            var bka = await _context.TblBank.FindAsync(id);

            _context.TblBank.Remove(bka);

            await _context.SaveChangesAsync();
            return bka;

        }

    }
}
