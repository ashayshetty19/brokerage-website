﻿using Microsoft.EntityFrameworkCore;
using MockCrud.Models;
using System;

namespace MockCrud.Repository
{
    public class UserDbRepository:IUserRepository
    {
        private BankDbContext _context;
      

        public UserDbRepository(BankDbContext context)
        {
            _context = context;

        }

     

        public async Task<List<User>> GetUsersAsync()
        {
            var data = await _context.TblUser.Include(r => r.BrokerageAccount).AsNoTracking().ToListAsync(); 
            return data;
        }



        public async Task<User?> GetUserByIdAsync(int id)
        {
            return await _context.TblUser.SingleOrDefaultAsync(i => i.UserId == id);



        }

        public async Task<User> AddUserAsync(User usr)
        {

            await _context.AddAsync(usr);

            await _context.SaveChangesAsync();

            usr.BrokerageAccount = new List<BrokerageAccount>();

            BrokerageAccount defaultBrokerageAccount = new BrokerageAccount();
            defaultBrokerageAccount.UserId = usr.UserId;
            defaultBrokerageAccount.AccountType = "Standard";

            Console.WriteLine(defaultBrokerageAccount);

            await _context.AddAsync(defaultBrokerageAccount);
            await _context.SaveChangesAsync();




            usr.BrokerageAccount.Add(defaultBrokerageAccount);






            return usr;

        }

        public async Task<User> EditUserAsync(int id, User UpdatedUser)
        {
            var u = await _context.TblUser.FindAsync(id);

            u.UserFirstName = UpdatedUser.UserFirstName;
            u.UserLastName = UpdatedUser.UserLastName;
            u.Password = UpdatedUser.Password;
            u.Job= UpdatedUser.Job;
            u.Joblocation= UpdatedUser.Joblocation;
            u.UserName = UpdatedUser.UserName;
            u.GrossSalary = UpdatedUser.GrossSalary;
            u.PrimaryLocation= UpdatedUser.PrimaryLocation;

            await _context.SaveChangesAsync();
            return u;

        }

        public async Task<User> DeleteUserAsync(int id)
        {
            var u = await _context.TblUser.FindAsync(id);

            _context.TblUser.Remove(u);

            await _context.SaveChangesAsync();
            return u;

        }











    }
}

