﻿using MockCrud.Models;

namespace MockCrud.Repository
{
    public interface IBrokerageRepository
    {
        Task<List<BrokerageAccount>> GetBrokeragesAsync();

        Task<BrokerageAccount?> GetBrokerageByIdAsync(int id);

        Task<List<BrokerageAccount?>> GetBrokerageByUsrIdAsync(int id);


        Task<BrokerageAccount> AddBrokerageAsync(BrokerageAccount Broker);



        Task<BrokerageAccount> DeleteBrokerageAsync(int id);
    }
}
