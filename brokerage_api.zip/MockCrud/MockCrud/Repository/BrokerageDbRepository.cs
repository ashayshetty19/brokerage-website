﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MockCrud.DTO;
using MockCrud.Models;

namespace MockCrud.Repository
{
    public class BrokerageDbRepository : IBrokerageRepository
    {

        private BankDbContext _context;


        public BrokerageDbRepository(BankDbContext context)
        {
            _context = context;

        }

        public async Task<List<BrokerageAccount>> GetBrokeragesAsync()
        {
            var data = await _context.TblBrokerage.Include(r => r.BankAccounts).AsNoTracking().ToListAsync();
            return data;
        }


        public async Task<BrokerageAccount?> GetBrokerageByIdAsync(int id)
        {
            return await _context.TblBrokerage.Include(r => r.BankAccounts).AsNoTracking().SingleOrDefaultAsync(i => i.BrokerageAccountId == id);

        }

        public async Task<List<BrokerageAccount?>> GetBrokerageByUsrIdAsync(int id)
        {
            return _context.TblBrokerage.Include(r => r.BankAccounts).AsNoTracking().Where(i => i.UserId == id).ToList();

        }

        public async Task<BrokerageAccount> AddBrokerageAsync(BrokerageAccount bra)
        {

            await _context.AddAsync(bra);

            await _context.SaveChangesAsync();

            return bra;

        }

        public async Task<BrokerageAccount> DeleteBrokerageAsync(int id)
        {
            var bra = await _context.TblBrokerage.FindAsync(id);

            _context.TblBrokerage.Remove(bra);

            await _context.SaveChangesAsync();
            return bra;

        }





    }
}
