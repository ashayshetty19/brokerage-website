﻿using MockCrud.Models;

namespace MockCrud.Repository
{
    public interface ILoginRepository
    {
        Task<User> AuthenticateAsync(string username, string password);
    }
}
