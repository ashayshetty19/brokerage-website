﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MockCrud.DTO;
using MockCrud.Models;
using MockCrud.Repository;
using System.Data;

namespace MockCrud.Controllers
{
    [Route("[controller]")]
    [ApiController]
    //[Authorize]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository repos;

        private readonly IMapper mapper;
        public UserController(IUserRepository repos, IMapper mapper)
        {
            this.repos = repos;
            this.mapper = mapper;
        }
        [Route("")]
        [HttpGet]

        public async Task<IActionResult> GetAllUsers()
        {

            var users = await this.repos.GetUsersAsync();

            var userdto = new List<UserDto>();

            //METHOD 1

            foreach (var user in users)
            {
                UserDto u = new UserDto();
                u.UserId = user.UserId;
                u.UserFirstName = user.UserFirstName;
                u.UserLastName = user.UserLastName;


                userdto.Add(u);
            }






            //   var userdto = mapper.Map<List<UserDto>>(users);

            return Ok(users);
        }


        [Route("Get/{id}")]
        [HttpGet]

        public async Task<IActionResult> GetUserId(int id)
        {

            var user = await this.repos.GetUserByIdAsync(id);
            if (user == null)
            {
                return NotFound();
            }
            else
                return Ok(user);
        }

        [Route("Add")]
        [HttpPost]
        //[Authorize(Roles = "Admin")]

        public async Task<IActionResult> AddUserAsync(User user)
        {

            await repos.AddUserAsync(user);
            return Ok(user);
        }





        [Route("Update/{id}")]
        [HttpPut]

        public async Task<IActionResult> EditUserAsync(int id, User user)
        {

            await repos.EditUserAsync(id, user);
            return Ok(user);



        }
        [Route("Delete/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteUserAsync(int id)
        {      
            var user = await repos.DeleteUserAsync(id);
            return Ok(user);
        }



    }
}
