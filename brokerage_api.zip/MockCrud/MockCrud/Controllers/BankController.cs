﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MockCrud.DTO;
using MockCrud.Models;
using MockCrud.Repository;

namespace MockCrud.Controllers
{
    [Route("[controller]")]
    [ApiController]
    //[Authorize]
    public class BankController : ControllerBase
    {

        private readonly IBankRepository repos;
        private readonly IBrokerageRepository br_repos;
        private readonly IMapper mapper;

        public BankController(IBankRepository repos, IBrokerageRepository br_repos,IMapper mapper)
        {
            this.repos = repos;
            this.br_repos = br_repos;
            this.mapper = mapper;
        }

        [Route("")]
        [HttpGet]
        public async Task<IActionResult> GetAllBanks()
        {

            var Banks = await this.repos.GetBanksAsync();


            return Ok(Banks);
        }


        [Route("Get/{id}")]
        [HttpGet]

        public async Task<IActionResult> GetBankId(int id)
        {

            var bka = await this.repos.GetBankByIdAsync(id);
            if (bka == null)
            {
                return NotFound();
            }
            else
                return Ok(bka);
        }

        [Route("GetByBrokerageId/{id}")]
        [HttpGet]
        public async Task<IActionResult> GetBankBraId(int id)
        {

            var bka = await this.repos.GetBankByBraIdAsync(id);
            if (bka == null)
            {
                return NotFound();
            }
            else
                return Ok(bka);
        }



        [Route("Add")]
        [HttpPost]
        //[Authorize(Roles = "Admin")]

        public async Task<IActionResult> AddBankAsync(BankDTO bak)
        {
            var bka = mapper.Map<BankAccount>(bak);
            var val = await ValidateBank(bka);
            if (val == 0)
            {
                await repos.AddBankAsync(bka);
                bak = mapper.Map<BankDTO>(bka);
                return Ok(bak);
            }
            if(val==1)
                return StatusCode(441);
            if (val == 2)
                return StatusCode(442);

            return StatusCode(443);
        }


        [Route("Update/{id}")]
        [HttpPut]

        public async Task<IActionResult> EditBankAsync(int id, BankAccount bka)
        {
            var val = await ValidateUpdate(bka);
            if (val == 0)
            {
                await repos.EditBankAsync(id, bka);
                return Ok(bka);
            }
            if (val == 1)
                return StatusCode(444);

            return StatusCode(443);
        }

        [Route("Delete/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteBankAsync(int id)
        {
            var val = await ValidateDelete(id);
            if (val == 0)
            {
                var bka = await repos.DeleteBankAsync(id);
                return Ok(bka);
            }
            return StatusCode(445);
        }

        private async Task<int> ValidateBank(BankAccount bank)
        {
            if (bank == null)
                return 3;  // 3 - bank details are null

            var br_acc = await this.br_repos.GetBrokerageByIdAsync(bank.BrokerageAccountId);
            var bank_count = br_acc.BankAccounts.Count();
            var bnk = br_acc.BankAccounts.Where(i => i.AccountType == "Current");
            var chck_count = bnk.Count();

            if (bank_count >= 3)
                return 1;    // already 3 bank accounts are added

            if (chck_count >= 2)
                return 2;   // already 2 checking accounts are added

            return 0;
        }

        private async Task<int> ValidateUpdate(BankAccount bank)
        {
            if(bank == null)
                return 3;

            var bnk_acc = await this.repos.GetBankByIdAsync(bank.AccountId);

            bank.OpenedDate = bnk_acc.OpenedDate;
            bank.CntDate = bnk_acc.CntDate;
            if (bnk_acc.OwnerName == bank.OwnerName)
                return 0;


            if (bnk_acc.Count >= 2)
            {
                var date = (int)(DateTime.Today - bnk_acc.CntDate).TotalDays;
                var month = date % 30;
                if (month <= 1)
                    return 1;
                bank.Count = 0;
            }

            if(bnk_acc.Count==0)
            {
                bank.Count = 1;
                bank.CntDate = DateTime.Today;
            }
            else { bank.Count++; }

            return 0;
        }

        private async Task<int> ValidateDelete(int id)
        {
            var bank = await this.repos.GetBankByIdAsync(id);
            var days = (int)(DateTime.Today - bank.OpenedDate).TotalDays;
            if (days > 30)
                return 0;
            return 1;
        }
    }
}
