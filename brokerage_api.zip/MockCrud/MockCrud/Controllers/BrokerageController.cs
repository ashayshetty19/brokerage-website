﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MockCrud.DTO;
using MockCrud.Models;
using MockCrud.Repository;

namespace MockCrud.Controllers
{
    [Route("[controller]")]
    [ApiController]
   // [Authorize]
    public class BrokerageController : ControllerBase
    {
        private readonly IBrokerageRepository repos;

      
        public BrokerageController(IBrokerageRepository repos)
        {
            this.repos = repos;
         
        }
        [Route("")]
        [HttpGet]
        public async Task<IActionResult> GetAllBrokerages()
        {

            var brokerages = await this.repos.GetBrokeragesAsync();


            return Ok(brokerages);
        }


        [Route("Get/{id}")]
        [HttpGet]

        public async Task<IActionResult> GetBrokerageId(int id)
        {

            var bra = await this.repos.GetBrokerageByIdAsync(id);
            if (bra == null)
            {
                return NotFound();
            }
            else
                return Ok(bra);
        }


        [Route("GetByUsr/{id}")]
        [HttpGet]

        public async Task<IActionResult> GetBrokerageusrId(int id)
        {

            var bra = await this.repos.GetBrokerageByUsrIdAsync(id);
            if (bra == null)
            {
                return NotFound();
            }
            else
                return Ok(bra);
        }



        [Route("Add")]
        [HttpPost]
       

        public async Task<IActionResult> AddBrokerageAsync(BrokerageAccount bra)
        {

            await repos.AddBrokerageAsync(bra);
            return Ok(bra);
        }

        [Route("Delete/{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteBrokerageAsync(int id)
        {
            var bra = await repos.DeleteBrokerageAsync(id);
            return Ok(bra);
        }




    }
}
