﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using MockCrud.DTO;
using MockCrud.Models;
using MockCrud.Repository;
using MockCrud.Token;

namespace MockCrud.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly ILoginRepository repository;
        private readonly IUserRepository repo;
        private readonly ITokenHandler token;
        public AuthController(ILoginRepository loginRepository, ITokenHandler token)
        {
            this.repository = loginRepository;
            this.token = token;

        }




        [Route("logindto")]
        [HttpPost]
        public async Task<IActionResult> Logindto(LoginDto user)
        {



            var result = await repository.AuthenticateAsync(user.UserName, user.Password);


            if (result != null)
            {
                var str = await token.CreateToken(result);

                TokStr ts = new TokStr();

                ts.key= str;

                return Ok(ts);
            }
            else
            {
                return BadRequest("Username or pass is invalid bro");
            }
        }
    }
}
